<?php

namespace Diginamic\Framework\Exception;

class RouteNotFoundException extends \Exception {}
